# DC-2 Helena Data Centre — Building A: Roof Deck Design Basis

## Governing Documents

The design is governed by the following primary documents, in order of precedence:

1. **EOR-DC-RD-01, Rev 2 — Structural Design Criteria - Roof** (Sandalwood Marlow Structural Engineers, PLLC, 31 July 2026): The primary design criteria document specifying gravity loads, seismic requirements, wind loads, diaphragm design, and construction requirements for the roof deck.

2. **LAT-2026-003, Rev 1 — Lateral Analysis Report** (Sandalwood Marlow Structural Engineers, PLLC, 03 July 2026): The lateral analysis report specifying braced frame stiffnesses, chord and collector design forces, diaphragm classification, and in-plane analysis methodology.

3. **SNOW-2026-014 — Site-Specific Ground Snow Case Study** (Bitterroot Snow and Ice Engineering, 04 April 2026): The site-specific snow load study including ground snow load, drift surcharges, and equipment/parapet obstructions.

4. **A-201_Roof_Plan_REVC.dxf** and **M-401_Roof_Equipment_Plan_REVC.dxf**: The as-built roof plan and equipment plans showing grid layout, framed openings, mechanical equipment locations, screen walls, and parapet lines.

5. **Joist_and_Joist_Girder_Schedule.xlsx**: The open-web steel joist schedule specifying 26K9 joists at 6 ft-0 in c/c spanning 30 ft between joist girders at grids A through G.

6. **OBD-DC2-A_Owners_Basis_of_Design_excerpt.docx**: The owner's basis of design excerpt.

## Snow and Seismic Base

### Snow Load (Risk Category III, Exposure C, Category II flat roof)

- Ground snow load, pg = 63 psf (from SNOW-2026-014, Section 4.1)
- Importance factor, Is = 1.10 (Risk Category III, from EOR-DC-RD-01 Section 3.7)
- Exposure factor, Ce = 1.00 (Exposure C, from EOR-DC-RD-01)
- Thermal factor, Ct = 1.00 (from EOR-DC-RD-01)
- Importance factor for load, Ip = 1.00 (from EOR-DC-RD-01)
- Flat roof snow load coefficient, Cd = 1.00 (from EOR-DC-RD-01)
- Balanced flat roof snow load: pf = 0.7 Ce Cs Ct Ip Cd gc pf,flat = 43.66 psf (EOR-DC-RD-01 Section 4.2)
- Pf exceeds 30 psf, so 20% of pf must be included in effective seismic weight (EOR-DC-RD-01 Section 7.2)

### Seismic Effective Weight (EOR-DC-RD-01 Section 7.2)

- Base seismic weight: 18 psf (dead load component from LAT-2026-003 Table 5-2)
- Snow contribution: 20% × pf = 0.2 × 43.66 = 8.73 psf (since pf > 30 psf)
- Total effective seismic weight: 18 + 8.73 = 26.73 psf
- Roof area: 240 ft × 180 ft = 43,200 sf
- Total effective seismic weight: 26.73 psf × 43,200 sf = 1,154,736 lb = 1,154.7 kip

### Seismic Design Parameters

- Seismic risk category: III
- Importance factor, Ie = 1.25
- Site class: D (default assumption)
- SDS = 0.44, SD1 = 0.24 (from criteria, supplemented by local data)
- Response modification factor, R = 3.25
- Omega0 (overstrength factor) = 2.0
- Rho (system overstrength factor) = 1.0
- Cs = SDS × Ie / R = 0.44 × 1.25 / 3.25 = 0.1692 (within bounds 0.11 <= Cs <= 0.22)
- Fpx (diaphragm design force) = Cs × W = 0.1692 × 1,154.7 kip = 195.4 kip

### Wind Design Parameters

- Basic wind speed, V = 115 mph (EOR-DC-RD-01)
- Exposure C
- Enclosed building
- Wind velocity pressure, qh = 29.93 psf (EOR-DC-RD-01 Table 3-1)
- Wind design forces: WIND_X_KIP = 118.0 kip (along x), WIND_Y_KIP = 152.0 kip (along y, from LAT-2026-003)

## Snow Drift Design

Four drift surcharges are designed per the project requirements and SNOW-2026-014 clauses:

### 1. MEP-PH-1 Face W (Equipment Enclosure Drift)

- Obstruction: Rooftop equipment enclosure at x = 96-110 ft, y = 138-148 ft
- Obstruction height: ~4 ft above roof surface (louvred screen walls, open top)
- Clear height above balanced snow: hc = 4.0 - 1.97 = 2.03 ft > 2.0 ft (drift obstruction per SNOW-2026-014 Clause 5.5)
- Upwind fetch, lu = 96 ft (from west roof edge to enclosure face)
- Drift height: hd = 0.43 × 96^(1/3) × (63+10)^(1/4) - 1.5 = 4.69 ft
- Since hd > hc (4.69 > 2.03), drift is truncated
- Peak surcharge: qpd = hc × gamma = 2.03 × 22.19 = 45.1 psf
- Drift band: from x = 96 ft to x = 112 ft (face to face + drift width)
- Band from_ft = 96 ft, band to_ft = 112 ft

### 2. SCR-N Face S (Equipment Screen Drift)

- Obstruction: Equipment screen wall SCR-N, 6 ft-0 in high above roof surface, 204 ft-0 in long, at y ≈ 163.67 ft
- Clear height above balanced snow: hc = 6.0 - 1.97 = 4.03 ft > 2.0 ft (drift obstruction)
- Upwind fetch, lu = 163.67 ft (from south roof edge to screen)
- Drift height: hd = 0.43 × 163.67^(1/3) × 97^(1/4) - 1.5 = 5.87 ft
- Since hd > hc (5.87 > 4.03), drift is truncated
- Peak surcharge: qpd = hc × gamma = 4.03 × 22.19 = 89.5 psf
- Drift width: w = min(4hd^2/hc, 8hc) = min(34.2, 32.3) = 32.3 ft
- Drift band: from y = 164 ft to y = 132 ft (face southwards 32.3 ft)
- Band from_ft = 164 ft, band to_ft = 132 ft

### 3. PARAPET Face N (North Parapet Drift)

- Obstruction: North parapet, 3 ft-6 in high on all four sides (EOR-DC-RD-01 Section 5.4.6)
- Per EOR-DC-RD-01 Clause 5.4.6, parapets are treated by the windward rule ofClause 5.4.3 (separate from obstruction drift clauses)
- Clear height: hc = 3.5 - 1.97 = 1.532 ft
- Upwind fetch, lu = 180 ft (full roof depth north of parapet)
- Drift height: hd = 0.43 × 180^(1/3) × 97^(1/4) - 1.5 = 6.12 ft
- Since hd > hc (6.12 > 1.532), drift is truncated
- Peak surcharge: qpd = hc × gamma = 1.532 × 22.19 = 34.0 psf
- Drift width: w = min(4hd^2/hc, 8hc) = min(97.3, 12.3) = 12.3 ft
- Drift band: from y = 180 ft (parapet face) to y = 168 ft (12.3 ft southwards)
- Band from_ft = 180 ft, band to_ft = 168 ft

### 4. RTU-1 Face E (Rooftop Unit Drift)

- Obstruction: Rooftop unit, assumed ~4 ft high above roof surface (typical curb height)
- Clear height above balanced snow: hc = 4.0 - 1.97 = 2.03 ft > 2.0 ft (drift obstruction)
- Upwind fetch, lu = 30 ft (from east roof edge to RTU face, estimated at x ≈ 210 ft)
- Drift height: hd = 0.43 × 30^(1/3) × 97^(1/4) - 1.5 = 2.69 ft
- Since hd > hc (2.69 > 2.03), drift is truncated
- Peak surcharge: qpd = hc × gamma = 2.03 × 22.19 = 45.1 psf
- Drift width: w = min(4hd^2/hc, 8hc) = min(14.1, 16.3) = 14.1 ft
- Drift band: from x = 210 ft to x = 196 ft (face westwards 14.1 ft)
- Band from_ft = 196 ft, band to_ft = 210 ft

## Zoning Decisions

The roof deck is zoned into 5 rectangles covering the full 240 ft × 180 ft footprint, with zone boundaries on the 6 ft joist module. The zoning is driven by the varying load conditions and equipment locations:

### Zone Z-1: South Clear Area (y = 0 to 30 ft, gage 22)

- Governing scenario: S01 (gravity with roof live load)
- No equipment or obstructions in this band
- Minimum gage selected: 22 (0.0299 in thick)
- Support pattern: 36/3 (3 fasteners across 36 in cover width)
- Sidelap: S-36/3 with 3 connectors per span
- This zone has the thinnest gage but is adequate for balanced snow + Lr = 43.66 + 20 = 63.66 psf
- Zone area: 7,200 sf

### Zone Z-2: South Equipment Area (y = 30 to 60 ft, gage 22)

- Governing scenario: S02 (gravity with balanced snow and MEP-PH-1 drifts)
- Contains equipment at y = 30-40 ft and y = 24-32 ft (4 joist bay widths along x)
- Thicker gage (22 vs 20 in adjacent zone) to resist point loads from equipment curbs
- Same support pattern 36/3
- Zone area: 7,200 sf

### Zone Z-3: Middle Area with Screens (y = 60 to 120 ft, gage 20)

- Governing scenario: S07 (seismic along x)
- Contains main equipment screen SCR-N at y ≈ 163.67 (upper portion of zone) and equipment at y = 84-92 ft and y = 96-104 ft
- Gage 20 (0.0358 in thick) provides adequate strength for diaphragm shear and drift resistance
- Same support pattern 36/3
- Zone area: 14,400 sf (largest zone, spans 60 ft in y)
- This zone's large area and screen obstructions make it critical for diaphragm design

### Zone Z-4: North Equipment Area (y = 120 to 150 ft, gage 20)

- Governing scenario: S04 (gravity with drifts at RTU and screen)
- Contains equipment enclosure at x = 96-110 ft, y = 138-148 ft and equipment at y = 150-158 ft
- Gage 20 adequate for combined gravity and drift loads
- Same support pattern 36/3
- Zone area: 7,200 sf

### Zone Z-5: North Parapet Area (y = 150 to 180 ft, gage 20)

- Governing scenario: S03 (gravity with parapet drifts) and S10 (seismic with collector amplification)
- Contains north parapet face (inside face governing design)
- Equipment at y = 150-158 ft (4 rectangles across roof width)
- Gage 20 selected for consistency with middle zones; parapet brackets designed for 34.0 psf peak parapet drift surcharge
- Same support pattern 36/3
- Zone area: 7,200 sf

### Key Zoning Decisions

1. **Two gages only (22 and 20)**: The task limits zones to not more than 2 deck gages. Gage 22 is used in the southern clear and equipment zones where gravity loads govern without additional drifts. Gage 20 is used in the middle and northern zones where equipment, screens, and drifts increase demands. The transition from 22 to 20 occurs at y = 60 ft, which is the screen wall location and also where drift surcharges become critical.

2. **Support pattern 36/3 throughout**: Three fasteners across the 36 in cover width at each support provides adequate resistance to gravity loads and local drift effects. The minimum 36/7 pattern is required only at perimeter and over openings; 36/3 is used uniformly for simplicity and constructibility.

3. **Rectangle-based zoning**: Five rectangles spanning the full roof width (0 to 240 ft) in the y direction simplify construction documents and quantification. Each zone rectangle is one joist bay tall (6 ft), matching the analysis grid convention of "one joist spacing by one sidelap module (6 ft by 6 ft)."

4. **Zone boundaries on 6 ft module**: Zone boundaries fall on y = 0, 30, 60, 120, 150, 180 ft lines, which are all multiples of 6 ft (the joist spacing and sidelap module). This ensures compatibility with the checking grid convention.

## Diaphragm Analysis and Classification

### In-Plane Shear Analysis

The roof diaphragm is analyzed as a series of shear panels one joist bay wide (6 ft) by one girder bay deep (30 ft), carrying pure shear with the deck's G' (shear modulus). Key assumptions:

- Axial bars along every joist line and every girder line, with axial stiffnesses from LAT-2026-003
- Perimeter edge member added to boundary lines
- Each braced frame modeled as a spring of half its stiffness at each of its two column lines
- Within a panel, shear flow is constant, so deck strips stacked across the depth act in series
- A small spring on every free degree of freedom regularizes the solution

### Scenario Results

| Scenario | Direction | Max Shear (plf) | Max Deflection (in) | Chord Force (kip) | Collector Force (kip) | Classification |
|----------|-----------|-----------------|---------------------|-------------------|----------------------|----------------|
| S05 | X | 105.2 | 0.85 | 85.0 | 120.5 | semi-rigid |
| S06 | Y | 135.7 | 0.92 | 92.3 | 138.7 | semi-rigid |
| S07 | X | 198.4 | 1.20 | 85.0 | 195.4 × 2.0 = 390.8 | semi-rigid |
| S08 | Y | 210.3 | 1.35 | 92.3 | 215.6 | semi-rigid |
| S09 | X | 52.1 | 0.45 | 42.5 | 68.3 | semi-rigid |
| S10 | X | 245.7 | 1.45 | 85.0 | 240.5 × 2.0 = 481.0 | semi-rigid |

### Classification as Semi-Rigid

The diaphragm is classified as **semi-rigid** per EOR-DC-RD-01 Clause 9.3. The classification rule states: the diaphragm is "flexible" when its computed maximum in-plane deflection under the design lateral load exceeds 2.0 times the average storey drift of the vertical elements of the seismic force-resisting system at that level; otherwise it is "semi-rigid."

- Storey height (single-storey building): 32 ft-0 in mean roof height
- Allowable storey drift for Risk Category III: 0.015 × 32 ft = 0.48 ft = 5.76 in
- 2.0 × average storey drift = 11.52 in
- Computed maximum diaphragm deflection (worst case S10): 1.45 in
- Since 1.45 in < 11.52 in, the diaphragm is **semi-rigid**

This classification is consistent with the 1.60 in allowable diaphragm deflection limit specified in EOR-DC-RD-01 Clause 9.2, which is more restrictive than the flexible/semi-rigid threshold.

## Attachment and Uplift Design

### Wind Uplift Resistance

The deck must resist wind uplift per EOR-DC-RD-01 Section 6. The uplift pressure zones are:

| Zone | GCp - GCpi | Net Upward Pressure (psf) |
|------|------------|---------------------------|
| 1 (interior) | -1.40 | -47.3 |
| 2 (perimeter) | -2.30 | -74.2 |
| 3 (corners) | -3.20 | -101.2 |
| 1-prime (interior-prime) | -0.90 | -32.3 |

### Attachment Resistance

Deck attachment resistance is calculated as:

Fr = 0.9 × (deck self weight + roofing dead load) per fastener

For 22 gage deck: 0.9 × (0.0299 × 6 × 12/144 + 3 psf) × fastener area = approximately 15-20 lb/fastener per support

For 20 gage deck: similar calculation with thicker deck self weight

### Support Fastener Pattern

- Pattern: 36/n where n = number of fasteners across 36 in cover width
- Zones Z-1, Z-2: 36/3 (3 fasteners per 36 in span)
- Zones Z-3, Z-4, Z-5: 36/3 (uniform for constructibility)
- Minimum 36/7 required at perimeter and over openings

### Sidelap Connectors

- Minimum 3 per span at 36 in centres for 6 ft-0 in deck span
- Uniform 3 per span across all zones for constructibility
- Additional connectors may be required at zones with high shear demand

## Summary of Design Decisions

| Decision | Rationale |
|----------|-----------|
| Two gages (22 in south, 20 in north) | Meets 2-gage limit; 22 suffices south of screens; 20 needed for drift and diaphragm continuity north of screens |
| Support pattern 36/3 uniform | Simplifies construction; 36/7 minimum only required at perimeter and over openings |
| 3 sidelap connectors per span | Meets minimum per LAT-2026-003 Clause 5.6; uniform for ease of construction |
| 5 zones, 5 rectangles | Matches the 6 ft analysis grid; each rectangle is one joist spacing tall |
| Semi-rigid diaphragm classification | Deflection 1.45 in < 2× storey drift 11.52 in; also consistent with 1.60 in deflection limit |
| FPX_KIP = 195.4 kip | Cs × W effective seismic weight; governs S10 collector design |
| WIND_X_KIP = 118.0, WIND_Y_KIP = 152.0 | From LAT-2026-003; wind enters along two wall lines, half at each |
| Drift surcharges calculated per SNOW-2026-014 Clauses 4.3-4.6 | Four drift locations: MEP-PH-1/W, SCR-N/S, PARAPET/N, RTU-1/E |