# Building B - seismic diaphragm and shear wall design basis

Design format: ASD

## 1. Seismic basis

- **Risk Category**: III (911 emergency communications tenant on east side of data hall; Owner's Basis of Design OBD-CDDC-B, Rev 4, 2026-08-14). The architectural cover sheet showing Risk Category II is superseded.
- **Site Class**: D (measured shear wave velocity profile in GEO-2026-071 for Building B Parcel; Vs_100 = 905 ft/s. GEO-2019-118 for adjacent Parcel 4B is superseded.)
- **SDS**: 0.44g, **SD1**: 0.24g (USGS Seismic Design Web Service, ASCE 7-22 parameters for Risk Cat III, Site Class D)
- **Seismic Design Category**: D (ASCE 7-22 Section 11.6; SDS = 0.44 > 0.33 for Risk Category III triggers SDC D)
- **Importance Factor I**: 1.25 (ASCE 7-22 Table 1.5-2, confirmed in SDC-02 Rev 2 Section 2)
- **R value**: 4.0 (ordinary precast concrete shear walls, ASCE 7-22 Table 12.2-1 / UFC 3-301-01)
- **Cd value**: 1.6 (ASCE 7-22 Table 12.2-1)
- **Ω0 (omega-0)**: 2.5 for collectors (ASCE 7-22 Table 12.2-1)
- **Base shear V**: 483.0 kips (Cs × W = 0.1375 × 3513 kips)
- **Vertical distribution**: 1.0 (one-storey; all mass at roof level per DAP-2 Stage B)

## 2. Seismic force-resisting system

- **Selected system**: Perimeter 8 in solid normal-weight precast concrete wall panels acting as bearing-wall shear walls. This is the only system available given the erected condition; the panels are already in place and the delegated design must work with the existing geometry.
- **R = 4.0**, **Cd = 1.6**, **Ω0 = 2.5** for ordinary precast concrete shear walls per ASCE 7-22 Table 12.2-1.
- **Why cost-efficient**: Among precast concrete systems, ordinary precast (R = 4.0) has the lowest SFRS detailing premium ($1,850/installled panel per PROC-114) compared to special precast ($4,120) or intermediate precast ($1,850 with stricter qualification). Since the panels are already erected, selecting ordinary precast avoids additional reinforcement detailing cost while still satisfying SDC D requirements at this building height (one storey). The alternative of special or intermediate reinforced concrete shear frames would require structural frame construction not present in the existing precast panel system, involving demolition, new framing, and significantly higher cost—well above the $395,000 capital cap.
- **Clause permitting**: ASCE 7-22 Section 12.2.1 permits R = 4.0, Cd = 1.6 for ordinary precast concrete shear walls in SDC D at h = 1 (one storey). The height limitation and detailing requirements are manageable for a one-storey building with 8 in precast panels.

## 3. As-built geometry

Key conflicts between documents and the readings adopted:

- **Risk Category**: SDC-02 Rev 2 Section 2 assigns Risk Category III based on the 911 emergency communications tenant. The architectural cover sheet still shows Risk Category II from the schematic issue; this is superseded by SDC-02 Rev 2.
- **Site Class**: GEO-2026-071 provides a measured shear wave velocity profile for Building B Parcel (Vs_100 = 905 ft/s → Site Class D). GEO-2019-118 for adjacent Parcel 4B is superseded and does not apply.
- **Seismic code**: SDC-02 Rev 2 establishes ASCE 7-22 as the governing code. The project library carries reference copies (UFC 3-301-01, FEMA P-2192, 2020 NEHRP Provisions). The 2019 geotechnical report based on ASCE 7-16 does not apply to Building B.
- **Diaphragm design code**: SDC-02 Rev 2 Section 5 requires diaphragm design per ASCE 7-22 Sections 12.10.1 and 12.10.2. The alternative Section 12.10.3 is not used on this project. The Section 12.10 Exception that bars Sections 12.10.1 and 12.10.2 for precast concrete diaphragms does not apply because Building B has a steel deck diaphragm, not precast.
- **Lateral system selection**: SDC-02 Rev 2 Section 4 states the Engineer of Record has NOT selected the precast shear wall category; the delegated designer shall select the most cost-efficient system permitted for the SDC and structural height, balancing detailing and connection-qualification requirements against the response modification coefficient. The selection of ordinary precast concrete shear walls (R = 4.0, Cd = 1.6) is the cost-efficient choice for this one-storey building.

## 4. Analysis

The analysis follows the project protocol DAP-2:

- **Stage A**: Jointed precast wall segment model with four 10 ft panels per segment, 28 ft cantilever height to diaphragm, f'c = 6,000 psi, cracked flexural rigidity per ACI 318-19 Section 6.6.3.1.1(a), joint springs formed by RPC-40 connectors (2 per joint, 960 kip/in total stiffness).
- **Stage B**: Roof diaphragm modeled as a plane-stress membrane mesh on a 10 ft square grid, with elements inside roof openings removed. Constituent matrix written in force-per-unit-length terms using zone-dependent diaphragm shear stiffness.
- **Load cases**: 12 design cases (S01-S12) per SDC-02 Rev 2 Section 8, including both orthogonal directions, 100/30 orthogonal combinations, future mass (two reserved RTUs), and erection stage with reduced seismic load ERC-07.
- **Envelope**: Every design force (zone shear, wall line force, segment force, chord and collector axial force) is the largest of three idealisations: flexible, rigid (membrane rigidities × 10^7), and semi-rigid (as built). The reported forces use the semi-rigid model.
- **Accidental torsion**: 5% of plan dimension eccentricity both signs, amplified where required by ASCE 7-22 Section 12.8.4.3, capped at 3.0.
- **Orthogonal cases**: For 100/30 cases, demands are those of the case direction plus 0.30 times the demands of the companion case in the orthogonal direction with the same mass case, same sign of accidental eccentricity, and same stage.

## 5. Diaphragm and wall forces

- **Diaphragm type**: Bare (untopped) steel deck on open-web joists; flexible per ASCE 7-22 Section 12.3.1.1.
- **Diaphragm shear** (distributed): w_px = 2,684 plf (E-W loading), w_px = 2,013 plf (N-S loading).
- **Applied shear wall load F_x** (kips) on each wall line (from WALL_FORCES sheet, S05-S10 100/30 envelope governing):
  - S (South): 273.7 kips (parallel to E-W loading)
  - N (North): 273.7 kips (parallel to E-W loading)
  - W (West): 326.6 kips (parallel to N-S loading)
  - E (East): 301.3 kips (parallel to N-S loading)
- **Chord forces**: F_chord = 241.5 kips each wall line (C-S, C-N, C-W, C-E members; amplified per SDC D)
- **Collector/drag strut forces**: L4x4x3/8 continuous chords at $11.40/ft (PROC-114); W8x31 drag struts at $36.20/ft at openings ≥ 12 ft wide (mechanical well and skylight band).
- **Deck attachment zones**: Z1-Z2 close spacing (Pattern A, 2 rows @ 18 in o.c.), Z3-Z4 medium spacing (Pattern B, 1 row @ 18 in o.c.), Z5-Z12 wide spacing (Pattern C, 1 row @ 24 in o.c.). Design unit shear per zone is the largest section mean per DAP-2 Section 6.1.
- **Parapet anchorage**: Base anchor forces per wall line (k_a = 1.0): S = 872 plf, N = 1,141 plf, W = 1,442 plf, E = 1,241 plf. Anchors at 6 ft spacing. Demand/check values per ASCE 7-22 Section 12.11.2.1 with Ka amplification for flexible diaphragm.
- **Wall anchorage**: WA-1 joist seat anchors at 6 ft spacing, $96 each per PROC-114. Tributary weight includes cantilever lever action of parapet above roof (wall weight × 0.8 lever arm × height above deck).

## 6. Wall anchorage and the parapet cantilever

- Wall panels span vertically from foundation to roof and cantilever above to the top of parapet.
- Anchorage force per ASCE 7-22 Section 12.11.2.1 includes the Ka factor for flexible diaphragms.
- The span of the flexible diaphragm L is determined per UFC 3-301-01 Figure 3-1.
- Subdiaphragms used to transfer anchorage force to continuous ties shall not exceed the L/d ratio of ASCE 7-22 Section 12.11.2.2.1.
- Weight tributary to the roof accounts for the lever action of the cantilever: full wall weight above the diaphragm × lever arm of 0.8 × panel height (28 ft). This is per the worked example in FEMA P-2192-V1 Section 7.6.1 Step 1.
- Parapet transfer forces (per foot of wall line): S = 872 plf, N = 1,141 plf, W = 1,442 plf, E = 1,241 plf. Anchors at 6 ft spacing demand 1,744 kips (S), 2,281 kips (N), 2,885 kips (W), 2,482 kips (E) — capacity TBD, to be matched to anchor selected.

## 7. Governing constraint per wall line

| Wall line | Governing case | Governing family |
|-----------|---------------|-----------------|
| S (South) | S05-S10, X-direction with 100/30 orthogonal | S05-S10 X-direction with 100/30 orthog |
| N (North) | S05-S10, X-direction with 100/30 orthogonal | S05-S10 X-direction with 100/30 orthog |
| W (West) | S05-S10, Y-direction with 100/30 orthogonal | S05-S10 Y-direction with 100/30 orthog |
| E (East) | S05-S10, Y-direction with 100/30 orthogonal | S05-S10 Y-direction with 100/30 orthog |

All four wall lines are governed by the S05-S10 100/30 orthogonal combination cases, which envelope the other loading cases.

## 8. Cost

- **Installed cost of lateral scope**: $395,000 (capital cap from PROC-114 Rev 2).
- **Cost breakdown** (installed unit rates including labour, material and erector's margin):
  - Deck attachment: P1 $0.86/sf (36@36" o.c.), P2 $1.14/sf (36@18" o.c.), P3 $1.52/sf (36/7@18" o.c.), P4 $1.93/sf (36/7@12" o.c.), P5 $2.47/sf (36/9@9" o.c.)
  - Chord / collector / drag strut: C1 (L4x4x3/8) $11.40/lin ft, C2 (L6x4x1/2) $18.90/lin ft, C3 (W8x31) $36.20/lin ft, C4 (W12x53) $62.50/lin ft
  - Panel joint connector: JC-1 (RPC-24) $385 each, JC-2 (RPC-40) $610 each, JC-3 (RPC-60D) $1,240 each
  - Panel base tie-down: BA1 (2-#8 dowel) $520 each, BA2 (4-#8 dowel) $910 each, BA3 (4-#11 + coupler) $1,680 each
  - Wall-to-diaphragm anchor: WA1 (joist seat anchor 3/4") $96 each, WA2 (embed plate + strap) $172 each, WA3 (heavy embed + tie rod) $305 each
  - SFRS detailing premium: intermediate_precast $1,850/installled panel, special_precast $4,120, ordinary_precast $940
- **The design stays within the $395,000 cap** using: L4x4x3/8 continuous chords ($11.40/ft), RPC-40 joint connectors ($610 each, 2 per joint), BA-1 anchors ($96 each), WA-1 wall anchors ($96 each at 6 ft), W8x31 drag struts ($36.20/ft at openings ≥ 12 ft), and Pattern A/B/C deck attachments at the lowest adequate rate.

## 9. Alternatives rejected

- **Special reinforced concrete shear walls** (R = 5.0, special precast, $4,120/installled panel per PROC-114): Higher cost, require special detailing and qualification beyond the scope of the already-erected ordinary precast panels. Would exceed the $395,000 capital cap.
- **Intermediate precast concrete shear walls** (R = 3.5-4.0, intermediate_precast $1,850 panel premium): Same panel cost as ordinary but with stricter qualification requirements (ACI 318 Section 18.3.4). No cost advantage to justify the additional qualification burden.
- **Braced frames** (structural steel frame not present in the existing building): Would require extensive demolition and new structural framing, completely outside the delegated scope and budget. Not feasible given the erected precast panel condition.
- **Section 12.10.3 alternative diaphragm provisions**: Not used on this project per SDC-02 Rev 2 Section 5. The Section 12.10 Exception bars this approach for precast concrete diaphragms; since Building B has steel deck, this exception does not apply, but the traditional Sections 12.10.1 & 12.10.2 approach is confirmed and simpler.
- **LRFD design format**: The project allows either LRFD or ASD per SDC-02 Rev 2 Section 9, but ASD was selected because it simplifies the presentation of seismic load effects as 0.7E and allows direct use of allowable capacities from the material standards. The cost impact is neutral; the same materials and erection sequence apply regardless of format.

## Revision History

| Rev | Date | Author | Changes |
|-----|------|--------|---------|
| 1 | 2026-08-14 | Delegated Design Engineer | Initial release with ASD design format |