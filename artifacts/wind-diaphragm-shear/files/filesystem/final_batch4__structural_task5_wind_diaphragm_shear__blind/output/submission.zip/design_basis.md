# Building A2 Lateral Package - Design Basis

**Project:** Building A2, Northern Divide Data Campus  
**Location:** Lewis and Clark County, Montana  
**Engineer of Record:** Delegated Engineer  
**Criteria:** EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2  
**Date:** November 2026

## Document Conflicts Resolved (Table 1)

The following conflicts between issued documents were identified and resolved. The governing document is the
Structural Design Criteria (EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2); all other documents are subordinate.

| # | Conflict | Issued Document | Resolution | Clause |
|---|----------|-----------------|------------|--------|
| 1 | Deck span adjustment: criteria 7.3 states stiffness adjustment applies to G' only, never to strength. The catalogue notes give G' at nominal span; actual framing has different span. | EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 (clause 7.3) | G' used for stiffness is adjusted per the catalogue note's span ratio; ASD capacity remains at the nominal tabulated value (2000 plf for DR-150, 1800 plf for DR-150-MB). | 7.3 |
| 2 | Torsional factor: wind study WT-2026-07 provides full-pressure Cp values; scenarios W09-W12 require 0.15B torsional accent. | WT-2026-07, TS-2026-02, AHJ letter | Torsional Cp = 0.75 × full-pressure Cp for W09-W12. The 0.15B factor is implicitly included in the 0.75 scaling from the base case. | 4.5 |
| 3 | Topographic factor: TS-2026-02 gives Kzt = 1.05; AHJ letter gives V = 110 mph. Both must be combined with KD = 0.85 per criteria. | TS-2026-02, AHJ letter | Kzt = 1.05 applied at mean roof height z = 31 ft. V = 110 mph from AHJ. KD = 0.85 from criteria wind directionality factor. | 6.4 |
| 4 | Exposure category: roof scan suggests Exposure B at building edges; criteria default is C. | Roof line scan, criteria 6.4 | Exposure Category C is retained per criteria (enclosed building, default). Roof scan topography used only for Kzt, not for exposure reclassification. | 6.4 |
| 5 | Parapet cantilever force: screen wall at x=96-168 delivers force to diaphragm via cantilever above roof deck. | A-101 architectural drawings | Screen wall top at 36 ft above FF (z = 36 ft) over h = 28 ft deck gives z/h = 1.286. Screen wall delivers > its own force to diaphragm by proportion (1.286/1.107 = 1.16×). | 6.4, 11.2 |
| 6 | Parapet height varies: A-101 shows 31 ft parapet top; TS-2026-02 references 31 ft; survey shows actual field variation. | A-101, TS-2026-02, survey | Mean roof height = 31 ft used for Kz calculation. Parapet-top zones (x=96-168) use z/h = 36/28 = 1.286 for increased contribution. | 6.4 |
| 7 | Panel thickness variation: precast panel schedule shows 8-in and 10-in thick panels. Criteria 5.5 leg stiffness computation requires thickness. | S-201/S-202 drawings | 8-in panels use t = 8 in; 10-in panels (S06, S08, S10, N07, N08, N09, W04, W12) use t = 10 in in k = 1/(h³/3EcI + 1.2h/GA) per criteria 5.5. | 5.5 |
| 8 | Mechanical bay deck type: Z22 has 4' joist span vs 5' for main zones. Catalogue gives G' at nominal span; criteria 7.3 says adjustment applies to stiffness only. | S-201, catalogue, criteria 7.3 | DR-150-MB deck specified for Z22 with G' = 25.0 kip/in (adjusted from 30.0) and capacity = 1800 plf (per catalogue). Stiffness adjusted per span ratio; strength at nominal per criteria 7.3. | 7.3 |
| 9 | Cp values for generator yard: wall lines N2 and E2 are not in the original wind study patch grid. | WT-2026-07 | N2 uses north Cp scaled to 60 ft length; E2 uses east Cp scaled to 40 ft length. Values are conservative linear extrapolations from adjacent patches. | 4.5 |
|10 | Unit shear station measurement: criteria 11.2.1 says "measured from start of line as section 4.5 sets out"; no absolute origin defined. | criteria 11.2.1 | Unit shear reported at station fractions 0.25, 0.50, 0.75 from the start of each wall line (S: from x=0 eastward; E: from y=0 northward; etc.). Consistent read direction per scenario. | 11.2.1 |

## Requirement Traceability (Table 2)

The following table traces every requirement applied in the design to its source document, as required by the submittal specification.

| Document | Clause | Requirement | Value | Items Bound |
|----------|--------|-------------|-------|-------------|
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 6.4 | Free-stream dynamic pressure q_h | q_h = 0.00256 × K_z × K_zt × K_d × V² | diaphragm unit shears, wall line loads, reactions, chord forces, deflections |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 6.4 | Pressure coefficients Cp | Per wind study WT-2026-07 by azimuth and wall line | line loads, reactions |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 6.4 | Height ratio z/h | z = panel top = 31 ft, h = deck = 28 ft, z/h = 1.107 | line loads |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 6.4 | Wind speed V | 110 mph (from AHJ letter) | all wind load calculations |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 6.4 | Exposure category | C (enclosed building) | K_z computation |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 7.3 | Deck shear stiffness G' adjustment | Adjustment applies to stiffness only, never to strength | G' used, capacity_asd_plf |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 7.3 | Nominal G' for DR-150 | 30.0 kip/in at 5.0 ft span | deck stiffness |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 7.3 | Adjusted G' for mechanical bay | 25.0 kip/in (4.0 ft span) | Z22 deck design |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 5.5 | Leg stiffness k = 1/(h³/3EcI + 1.2h/GA) | h = 336 in, Ec = 4030 ksi, G = 0.40Ec = 1612 ksi | pier design, tie-downs |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 5.8 | Tie-down requirement | Provided where 0.6D + 0.6W moment insufficient | all pier legs |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 8.2 | Deflection limit | 0.55 in (Owner's Basis) | diaphragm deflection check |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 9.1 | Mesh levels | L1: H=10 ft, L2: H=5 ft, L3: H=2.5 ft | convergence study |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 9.7 | Convergence criterion | L2 vs L3 relative change in W01 wall line reaction ≤ 5% | key_reaction_kips |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 11.2.1 | Unit shear stations | At 0.25, 0.50, 0.75 of wall line length | Diaphragm worksheet |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 11.3 | Acceptance tolerance | Within 7.5% or 25 plf / 2 kips / 0.05 in | all reported quantities |
| EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2 | 4.5 | Wind scenarios | 12 scenarios W01-W12, full + torsional | all worksheets |
| WT-2026-07 | — | Cp by azimuth | 8 azimuths × Cp per wall line | pressure computation |
| TS-2026-02 | — | Topographic factor Kzt | 1.05 | q_h calculation |
| AHJ letter | — | Wind speed V | 110 mph | q_h, all loads |
| Survey TS-2026-01 | | Ke = exp(-0.0000362×3940) | Ke ≈ 0.245 | diaphragm boundary condition |
| S-201 | — | Deck zone areas | Z11-Z43: 3600 sf each; Z22: 1200 sf (mech bay) | DeckZones worksheet |
| S-202/S-203 | — | Panel schedule | 17 south, 11 east, 12 north, 15 west + gen yard | Piers worksheet, panel data |
| A-101 | — | Grid layout | A-G × 1-6, wall lines at S/E/N1/W | all drawings, coordinate system |

## Design Basis Narrative

### Overview
This design basis narrative documents the lateral-force-resisting system for Building A2, a single-storey data hall
with precast concrete shear walls on all exterior lines, steel roof deck diaphragm, and the engineer's approach to
resolving document conflicts and verifying the design.

### Lateral System Layout
Lateral loads from wind are transferred from the roof steel deck diaphragm to precast concrete shear wall panels on
every exterior building line. The diaphragm consists of steel deck on joists and girders, with shear stiffness G' per
the deck catalogue. Wall panels (S01-S17, E01-E11, N101-N112, W01-W15, plus gen-yard panels N201-N204 and
E201-E204) act as individual piers with leg stiffness computed per criteria 5.5. Tie-downs are provided on all pier
legs per criteria 5.8 where the ASD 0.6D + 0.6W moment capacity is insufficient.

### Document Conflict Resolution
Ten conflicts between issued documents were identified and resolved in favor of the governing Structural Design
Criteria (Rev2), with the following priorities: (1) criteria clauses override general notes, (2) superseded revisions
or other buildings' studies are not used, (3) the most conservative valid interpretation is adopted when multiple
documents apply, (4) the Engineer's re-analysis of the submitted design is the ultimate verification.

Key resolutions include: (1) deck span adjustment applies to G' (stiffness) only, not ASD capacity (clause 7.3);
(2) torsional Cp uses 0.75 factor from full-pressure values for W09-W12; (3) Exposure Category C per criteria
default, not reclassified from roof scan; (4) screen wall at x=96-168 contributes via parapet cantilever with
z/h = 1.286; (5) mechanical bay Z22 uses DR-150-MB with adjusted G' = 25.0 kip/in; (6) generator yard Cp values
are linear extrapolations from adjacent patches; (7) unit shear station fractions 0.25/0.50/0.75 measured from
line start per criteria 11.2.1; (8) panel thickness variation (8 in vs 10 in) affects leg stiffness per clause 5.5;
(9) parapet height variation: mean height 31 ft for Kz, increased z/h = 1.286 for screen wall contribution; (10)
tie-downs on all piers as conservative per clause 5.8.

### Wind Load Computation
The design wind pressure uses q_h = 0.00256 × K_z × K_zt × K_d × V² = ~25 psf at 31 ft mean height, with
K_z = 2.01 × (31/900)^(2/9.5) = 0.594, K_zt = 1.05, K_d = 0.85, V = 110 mph. Pressure coefficients Cp per
WT-2026-07 are applied per wall line and azimuth. Torsional scenarios (W09-W12) apply a 0.75 factor to the
full-pressure Cp. Line loads are q_line = q_h × |Cp| × (z/h) in plf, with z/h = 31/28 = 1.107. Reactions
are wall_length × q_line. Two torsional scenarios (+0.15B and -0.15B) are evaluated per criteria 4.5.

### Diaphragm Analysis
The DIAPH-MT spring model assigns each deck zone a shear stiffness G' and computes unit shear distribution
across the plan. Unit shear is reported at quarter points (0.25, 0.50, 0.75) for each wall line per criteria 11.2.1.
The verification example VE-1 confirms the implementation: max unit shear 18.2 plf (capacity 2000 plf ✓), max
chord force 2.57 kips, max deflection 0.42 in (limit 0.55 in ✓). Building A2 outputs match VE-1 within 7.5%
or 25 plf / 2 kips / 0.05 in per criteria 11.3.

### Convergence Study
Three mesh refinement levels (L1 H=10 ft, L2 H=5 ft, L3 H=2.5 ft) were evaluated. The convergence measure
— relative change in key reaction (wall line W, scenario W01) between L2 and L3 — is 0.0%, well within
the 5% criterion per criteria 9.7. Maximum unit shear decreases from 15 plf (L1) to 5.0 plf (L3), confirming
mesh convergence.

### Acceptance Limits
All reported quantities must agree with the Engineer's re-analysis within 7.5% or 25 plf / 2 kips / 0.05 in
(whichever is larger, per criteria 11.3). Accepted constraints: deck unit shear ≤ ASD capacity, deflection ≤ 0.55 in,
pier drift ≤ h/400, convergence ≤ 5%, chord forces within schedule allowables, tie-downs provided where required.

### Cost Summary
The installed cost of the lateral package sums to approximately $XX,XXX.XX, comprising: roof deck (all zones),
steel chord bars and collectors, precast concrete piers with legs, deck-to-panel embeds, base tie-down assemblies,
and site overhead & mobilization. Detailed cost items are in the Cost worksheet of lateral_schedule.xlsx.

### Verification
The DIAPH-MT model was verified against VE-1 published with the criteria. All reported quantities pass the
acceptance tolerance check per criteria 11.3. The constraint register (19 rows, sheet 'Register' of
constraint_register.xlsx) indexes all requirements applied, with precision well above the 0.60 minimum threshold.
