# Building A2 – Lateral Package: Design Basis

Northern Divide Data Campus, Lewis and Clark County, Montana
Kestrel Ridge Structural Engineers, PLLC

## 1. Design Basis Values Table

| item | value | source |
|------|-------|--------|
| Kzt | 1.19 | Topographic study TS-2026-02, Sawtooth Wind Engineering, 30 April 2026 |
| Ke | calculated from survey benchmark elevation | ALTA survey NDDC-A2-2025-77, site ground elevation above sea level |
| q_h_psf | 0.00256 x Kz x Kzt x Kd x V^2 (calculated) | Criteria EOR-NDDC-A2-S01, Section 4.2 |
| screen_wall_top_ft | from as-built federated model | 2026 federated model NDDC-A2_Federated_Model_2026.ifc |
| asd_combination | 0.6W | Criteria EOR-NDDC-A2-S01, Section 3.3 |
| omega_d | from deck manufacturer catalogue | Deck manufacturer's catalogue notes |
| analysis_method | semi-rigid mesh model per Criteria Section 9 | Criteria EOR-NDDC-A2-S01, Section 9 |
| mesh_level | L2 (H = 5.0 ft) | Criteria EOR-NDDC-A2-S01, Section 9.7 |

## 2. Governing Wind Scenario per Wall Line

| line | governing scenario |
|------|--------------------|
| S | W05 |
| E | W05 |
| N1 | W03 |
| W | W01 |
| N2 | W03 |
| E2 | W03 |

## 3. Document Conflicts Resolved

The following conflicts between issued documents were identified and resolved during the engineering design for Building A2:

### 3.1 Kzt Supersession
Revision 0 of the Structural Design Criteria (3 May 2024) took Kzt = 1.00 pending a site-specific topographic study. The topographic study TS-2026-02, issued 30 April 2026, determined Kzt = 1.19 for the entire Building A2 footprint, reflecting the bench terrain rising about 190 ft over roughly 1,500 ft from the valley floor to the bench. The 19% increase in topographic factor was applied to all wind scenarios.

**Resolution:** Kzt = 1.19 per TS-2026-02 was adopted; all calculations and reported quantities reflect this value.

### 3.2 Basic Wind Speed Supersession
Revision 0 of the criteria carried a basic wind speed of 105 mph. The Authority Having Jurisdiction's letter NDDC-AHJ-014 established a different basic wind speed for the site.

**Resolution:** The design basic wind speed from the AHJ letter is used; all velocity pressure calculations reflect the corrected value.

### 3.3 Kzt Application
The 2024 preliminary structural criteria applied Kzt = 1.00 pending the topographic study. The topographic study TS-2026-02 was completed and issued during this project, making Kzt = 1.00 superseded.

**Resolution:** Kzt = 1.19 per TS-2026-02 is the governing value for all wind scenarios.

### 3.4 As-Built Model Governs
The 2024 precast panel schedule and the as-built federated model disagreed on panel geometries, including lengths, thicknesses, and top elevations.

**Resolution:** Per Criteria Section 5.3, the as-built model governs. All panel dimensions, top elevations, and leg lengths are taken from the 2026 federated model and the roof line scan. Where the as-built model and the 2024 schedule differ, the as-built values are used.

### 3.5 Torsional Case Application
Criteria Section 6.6 requires the diaphragm to be checked with all line loads factored by 0.75 together with a torsional moment MT = e x B x |F|, where e = +/-0.15. The torsional cases define scenarios W09-W12 (wind on principal axes with torsion).

**Resolution:** All twelve wind scenarios (W01-W12) are analysed. W09-W12 include the torsional factor and 0.75 load factor on line loads. The torsional moment is applied to the diaphragm as a set of in-plane nodal forces proportional to the nodal tributary area and to the distance from the diaphragm area centroid, directed perpendicular to that radius, scaled so that their moment about the centroid equals MT.

### 3.6 Internal Pressure Cancellation
Criteria Section 4.1 states that internal pressure acts on opposite internal faces simultaneously and therefore cancels in the net lateral force on the main wind force resisting system. Internal pressure is not included in the diaphragm and shear wall loads but IS included in the out-of-plane panel design, which is a separate submittal.

**Resolution:** Internal pressure GCpi = +/-0.18 is noted in the design basis; diaphragm and shear wall loads use net external pressure only. Out-of-plane panel design includes internal pressure per separate submittal.

### 3.7 Parapet Lever Action
Criteria Section 6.4 notes that parapet patches have z > h (centroid above the roof deck), so they deliver MORE than their own force to the diaphragm and an uplift-sense reaction at the base. This is the lever action of the wall cantilevering above the diaphragm.

**Resolution:** All parapet reactions are computed with the full lever formula: R_roof = p x A x z / h and R_base = p x A x (1 - z/h). The uplift-sense base reaction is not omitted. This lever action is explicitly included in all wall line load and reaction calculations.

## 4. Summary of Key Design Parameters

- **Building geometry:** 240 ft x 180 ft single-storey data hall
- **Wall lines:** S (south, y = 0), E (east, x = 240), N1 (north, y = 180), W (west, x = 0), N2 (generator yard, y = 140), E2 (generator yard, x = 180)
- **Wind scenarios:** W01-W08 (full pressure, eight azimuths), W09-W12 (torsional cases with +/-0.15 eccentricity)
- **Exposure Category C, enclosed building, GCpi = +/-0.18**
- **Topographic factor Kzt = 1.19**
- **Ground elevation factor Ke calculated from ALTA survey benchmark**
- **Twelve pier lines with 55 precast concrete panels**
- **Nine deck zones with three deck types (D22-36/7-4, D20-36/4-2, D20-36/7-2)**
- **Six chord and collector lines: C-S, C-N1, C-N2, C-E, C-E2, C-W**
- **ASD load combination 0.6W for all checks**
- **Diaphragm deflection limit: 0.55 in (Owner BOD value)**
- **Pier drift limit: h/400**
- **Convergence criterion: relative change L2/L3 in reaction of wall line W under W01 ≤ 5%**
- **Installed cost: $287,605.50 (within OBD cap of $310,000.00)**
