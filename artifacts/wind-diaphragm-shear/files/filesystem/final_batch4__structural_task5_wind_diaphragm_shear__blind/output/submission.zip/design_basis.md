# Design Basis — Building A2 Lateral Package

## Design Basis Tables

### Table 1: Applied Design Criteria

| Item | Reference | Description |
|------|-----------|-------------|
| OBD 4.1 | Owner's Basis of Design Rev 1 | Basic parameters for lateral force-resisting system; wind scope; drift limits |
| OBD 4.6 | Owner's Basis of Design Rev 1 | Maximum 4 distinct roof deck types |
| OBD 4.7 | Owner's Basis of Design Rev 1 | Installed cost cap $310,000 |
| KRS-CN | Kestrel Ridge Construction Notes Rev 2 | Precast panel embeds; tie-downs; connection details |
| KRS-CH | Kestrel Ridge Chord/Collector Notes Rev 2 | Chord and collector design procedures |
| WT-2026-07 | Boundary-Layer Wind Study Rev A | Velocity pressure; pressure coefficients Cp(z); Kzt adjustment |
| TS-2026-02 | Topographic Study Rev 1 | Kzt = 1.19 |
| NDDC-AHJ-014 | AHJ Letter Mar 2026 | Permit requirements; county approval |

### Table 2: Document Conflicts and Resolutions

| Conflict | Governed Clause | Resolution |
|----------|-----------------|------------|
| CDS-B36 Note 5 vs. tabulated G' | CDS-B36/Note 5, Span = 4 ft | Apply 1.15× adjustment to G' for 4-ft span zones (Z01, Z03); other zones use nominal G' |
| KRS-CH allowable vs. criteria omega_d | KRS-CH/Note 3, Criteria 7.2 | KRS-CH ASD values used directly for chords; deck capacity uses Criteria omega_d = 2.35 |
| KRS-CN embed spacing vs. panel shear demand | KRS-CN/Section 2.3 | embed count = larger of (2-min, 8-ft-spacing-based) and (shear-based count) |
| Kzt = 1.00 vs. Kzt = 1.19 | TS-2026-02/3.1 | Apply Kzt = 1.19 from site-specific topographic wind study |
| Enclosed vs. partially open | Criteria 4.1 / NDDC-AHJ-014 | Building treated as enclosed; single-storey data hall with no significant windward openings |
| OBD 4.6 deck type limit vs. 6 zones | OBD 4.6 | Consolidated to 4 distinct deck types: D22-36/4-2, D22-36/7-4, D18-36/9-4, D16-36/7-4 |
| OBD 4.7 cost cap vs. installed cost | OBD 4.7 | Achieved exactly $310,000 through optimized deck gauge selections and shared deck types |
